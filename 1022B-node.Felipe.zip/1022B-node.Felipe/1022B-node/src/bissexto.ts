function ehAnoBissexto(a:number):boolean{
    return a%4==0
}
export {ehAnoBissexto}