function ehPositivo(a:number):boolean{
    return a>0
}
export {ehPositivo}