function concatenarStrings(ftr1:string, ftr2:string):string{
  
  return ftr1 + ftr2;
}
export {concatenarStrings}