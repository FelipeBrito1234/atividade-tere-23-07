function encontrarMenorNumero(numeros:number[]):number{
    
    if(numeros.length === 0 ){
     return 0;
    }
     let menos = numeros[0];

     for (let i = 1; i< numeros.length; i++) {
        if (numeros[i] < menos){
            menos = numeros[i];
     }
     }


    return menos;
    }
export {encontrarMenorNumero}