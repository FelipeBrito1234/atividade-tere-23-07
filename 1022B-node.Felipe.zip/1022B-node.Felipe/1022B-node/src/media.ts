function calcularMedia(a:number,b:number,c:number):number{
    return (a+b+c)/3
}
export {calcularMedia}