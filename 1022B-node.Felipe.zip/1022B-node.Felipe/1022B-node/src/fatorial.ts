function calcularFatorial(a:number):number{
    let fot = a;
    if (a === 0  || a ===1)
        return 1

    while (a>1){
        a--;
        fot= fot*a
    }
    return fot
}

export {calcularFatorial}