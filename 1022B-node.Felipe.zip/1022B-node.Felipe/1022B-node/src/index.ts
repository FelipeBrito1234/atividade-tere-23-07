
function soma(a:number,b:number):number{
return a+b
}

function subtrair(a:number,b:number):number{
    return a-b
    }
function isPar(a:number):boolean{
 return a%2==0
}

export {soma,subtrair,isPar}